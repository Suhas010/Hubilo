/**
 * App config goes here
 */

export const config = {
	// Language
	// EN - English
	// HN - Hindi
	// MR - Marathi
	lang: 'EN',

};

